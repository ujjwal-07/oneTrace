"use client";

import { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css"; // Keep default styles

const CalendarPage = () => {
  const [date, setDate] = useState<Date | null>(new Date());

  return (
    <div className="p-6 min-h-screen bg-gray-100 flex flex-col items-center">
      <h1 className="text-3xl font-bold mb-6 text-gray-800">📅 Calendar</h1>

      <div className="bg-white p-4 shadow-lg rounded-lg">
        {/* Wrapper to apply Tailwind styles on the calendar */}
        <div className="react-calendar w-full">
          <Calendar
            onChange={(value) => setDate(value as Date)}
            value={date}
            className="w-full border-none"
          />
        </div>
      </div>

      <p className="mt-4 text-lg font-semibold text-gray-900">
        Selected Date: <span className="text-blue-600">{date?.toDateString()}</span>
      </p>

      {/* Tailwind-based Calendar Fixes */}
      <style>{`
        .react-calendar {
          max-width: 400px;
          border-radius: 10px;
          font-family: sans-serif;
          color: #1f2937; /* Dark text */
        }

        /* Month & Year Header */
        .react-calendar__navigation {
          @apply flex items-center justify-between bg-gray-800 text-white font-bold p-3 rounded-md;
        }

        .react-calendar__navigation button {
          @apply text-white;
        }

        /* Calendar Days */
        .react-calendar__tile {
          @apply p-10 font-semibold rounded-lg text-gray-1000 transition-all;
        }

        .react-calendar__tile:hover {
          @apply bg-blue-200;
        }

        .react-calendar__tile--active {
          @apply bg-blue-600 text-white;
        }
      `}</style>
    </div>
  );
};

export default CalendarPage;
