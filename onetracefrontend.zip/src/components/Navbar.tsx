"use client"; // Required for interactive components

import Link from "next/link";

const Navbar = () => {
  return (
    <aside className="w-64 h-screen bg-gray-900 text-white p-5 flex flex-col fixed">
      <h1 className="text-xl font-bold mb-5">OneTrace</h1>
      <nav className="space-y-3">
        <Link href="/" className="block p-2 hover:bg-gray-700 rounded">
          Home
        </Link>
        <Link href="/calendar" className="block p-2 hover:bg-gray-700 rounded">
          Calendar
        </Link>
        <Link href="/performance" className="block p-2 hover:bg-gray-700 rounded">
          performance
        </Link>

        <Link href="/LeaderBoard" className="block p-2 hover:bg-gray-700 rounded">
          LeaderBoard
        </Link>

        <Link href="/DiscussQ" className="block p-2 hover:bg-gray-700 rounded">
          Discuss Your Query
        </Link>


        <Link href="/profile" className="block p-2 hover:bg-gray-700 rounded">
Profile        </Link>
      </nav>
    </aside>
  );
};

export default Navbar;
